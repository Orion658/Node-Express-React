const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 8080;

// In-memory array to store books
let books = [];
let idCounter = 1;

app.use(bodyParser.json());
app.use(cors())

// Create a new book
app.post('/books', (req, res) => {
  const { name, author, price } = req.body;

  if (!name || !author || !price) {
    return res.status(400).json({ error: 'Please provide name, author, and price for the book.' });
  }

  const newBook = {
    id: idCounter++,
    name,
    author,
    price
  };

  books.push(newBook);

  res.status(201).json(newBook);
});

// Get all books
app.get('/books', (req, res) => {
  res.json(books);
});

// Get a book by ID
app.get('/books/:id', (req, res) => {
  const bookId = parseInt(req.params.id);

  const foundBook = books.find(book => book.id === bookId);

  if (!foundBook) {
    return res.status(404).json({ error: 'Book not found.' });
  }

  res.json(foundBook);
});

// Update a book by ID
app.put('/books/:id', (req, res) => {
  const bookId = parseInt(req.params.id);
  const { name, author, price } = req.body;

  const foundBookIndex = books.findIndex(book => book.id === bookId);

  if (foundBookIndex === -1) {
    return res.status(404).json({ error: 'Book not found.' });
  }

  const updatedBook = {
    id: bookId,
    name: name || books[foundBookIndex].name,
    author: author || books[foundBookIndex].author,
    price: price || books[foundBookIndex].price
  };

  books[foundBookIndex] = updatedBook;

  res.json(updatedBook);
});

// Delete a book by ID
app.delete('/books/:id', (req, res) => {
  const bookId = parseInt(req.params.id);

  books = books.filter(book => book.id !== bookId);

  res.json({ message: 'Book deleted successfully.' });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
