import React, { useEffect, useState } from 'react'
import Form from './components/Form'
import Table from './components/Table'

const App = () => {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8080/books')
      .then((response) => response.json())
      .then((data) => setBooks(data))
      .catch((error) => console.error('Error fetching books:', error));
  }, []);

  const addBook = (newBook) => {
    setBooks((prevBooks) => [...prevBooks, newBook]);
  };

  return (
    <div className='App'>
      <Form addBook={addBook} />
      <Table books={books} />
    </div>
  )
}

export default App

