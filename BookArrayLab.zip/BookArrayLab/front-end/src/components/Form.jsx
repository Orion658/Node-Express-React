import React, { useState } from 'react'

const Form = ({addBook}) => {
    const [book, setBook] = useState({
        name: '',
        author: '',
        price: '',
      });
    
      const handleChange = (e) => {
        const { name, value } = e.target;
        setBook((prevBook) => ({
          ...prevBook,
          [name]: value,
        }));
      };
    
      const handleSubmit = async (e) => {
        e.preventDefault();
    
        try {
          const response = await fetch('http://localhost:8080/books', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(book),
          });
    
          if (response.ok) {
            const newBook = await response.json();
            addBook(newBook);
            setBook({
              name: '',
              author: '',
              price: '',
            });
          } else {
            console.error('Failed to add book:', response.statusText);
          }
        } catch (error) {
          console.error('Error:', error);
        }
      };

  return (
    <div className='BookForm'>
        <h2>Form</h2>
        <form id="bookForm">
        <label htmlFor="name">Name:</label>
        <input type="text" id="name" name="name" onChange={handleChange} required/>

        <label htmlFor="author">Author:</label>
        <input type="text" id="author" name="author" onChange={handleChange}  required/>

        <label htmlFor="price">Price:</label>
        <input type="number" id="price" name="price" step="10" onChange={handleChange} required/>

        <button type="button" onClick={handleSubmit}>Add Book</button>
        </form>
    </div>
  )
}

export default Form
