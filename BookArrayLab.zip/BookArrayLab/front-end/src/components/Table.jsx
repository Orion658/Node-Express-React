import React from 'react'

const Table = ({books}) => {
  return (
    <div>
       <h2>Book List</h2>
      <table style={{ borderCollapse: 'collapse', width: '100%' }}>
        <thead>
          <tr>
            <th style={{ padding: '8px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>ID</th>
            <th style={{ padding: '8px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>NAME</th>
            <th style={{ padding: '8px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>AUTHOR</th>
            <th style={{ padding: '8px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>PRICE</th>
          </tr>
        </thead>
        <tbody>
          {books.map((book) => (
            <tr key={book.id}>
              <td style={{ padding: '8px', borderBottom: '1px solid #ddd' }}>{book.id}</td>
              <td style={{ padding: '8px', borderBottom: '1px solid #ddd' }}>{book.name}</td>
              <td style={{ padding: '8px', borderBottom: '1px solid #ddd' }}>{book.author}</td>
              <td style={{ padding: '8px', borderBottom: '1px solid #ddd' }}>{book.price}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default Table
