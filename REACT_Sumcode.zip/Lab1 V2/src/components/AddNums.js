import React, { useEffect, useState } from "react";
import "./Add.css";

const AddNums = () => {
  const [nums, setNums] = useState({ num1: '', num2: '' });
  const [result, setResult] = useState(null);

  useEffect(() => {
    const storedResult = localStorage.getItem("result");
    if (storedResult) {
      setResult(parseFloat(storedResult));
    }

    const timeoutId = setTimeout(() => {
      setResult(null); 
      localStorage.setItem("result", null);
    }, 2000);

    return () => clearTimeout(timeoutId);
  }, []);

  const handleCalculate = () => {
    const parsedNum1 = parseFloat(nums.num1);
    const parsedNum2 = parseFloat(nums.num2);

    if (!isNaN(parsedNum1) && !isNaN(parsedNum2)) {
      const sum = parsedNum1 + parsedNum2;
      setResult(sum);
      localStorage.setItem("result", sum);
    }
  };
  
  const handleNumChange = (e, numName) => {
    e.preventDefault();
    setNums({
      ...nums,
      [numName]: e.target.value,
    });
  };

  return (
    <form>
      <div className="container">
        <div>
          <label>Number 1</label>
          <input
            type="number"
            id="num1"
            placeholder="Enter first Number"
            value={nums.num1}
            onChange={(e) => handleNumChange(e, "num1")}
          />
        </div>
        <div>
          <label>Number 2</label>
          <input
            type="number"
            id="num2"
            placeholder="Enter second Number"
            value={nums.num2}
            onChange={(e) => handleNumChange(e, "num2")}
          />
        </div>

        <button onClick={handleCalculate}>ADD</button>
        {result !== null && <p>The sum is: {result}</p>}
      </div>
    </form>
  );
};

export default AddNums;
