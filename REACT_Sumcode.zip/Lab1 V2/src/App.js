import React from 'react'
import Add from './components/AddNums'
import './App.css'

const App = () => {
  return (
    <div>
      <Add/>
    </div>
  )
}

export default App
