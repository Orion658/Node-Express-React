const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const app = express();

const db = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"password",
    database:"lama"
});

// by default we cant send any req data from client to sserver
// Write a Express middleware
app.use(express.json());
app.use(cors());

// api req using express
app.get("/", (req,res)=>{
    res.json("This is a homepage ..")
});

app.get("/books", (req,res)=>{
    const q = "SELECT * FROM Books";
    // run query
    db.query(q, (err, data)=>{
        if(err) return res.json(err);
        return  res.json(data);
    })
})

app.get("/books/:id", (req,res)=>{
    console.log("update requested")
    const bookId = req.params.id;
    const q = "SELECT * FROM Books where id = ?";
    // run query
    db.query(q, [bookId], (err, data)=>{
        if(err) return res.json(err);
        return res.json(data);
    })
})

app.post("/books", (req,res)=>{
    const q = "INSERT INTO Books (`title`,`description`,`cover`,`price`) values (?)";
    const values = [
        req.body.title,
        req.body.description,
        req.body.cover,
        req.body.price
    ]

    db.query(q, [values], (err, data)=>{
        if(err) return res.json(err);
        return res.json("Book created successfully ..")
    })
});

app.delete("/books/:id", (req,res)=>{
    const bookId = req.params.id;
    const q = "Delete from Books where id=?";

    db.query(q, [bookId], (err,data) => {
        if(err) return res.json(err);
        return res.json("Book has been deleted successfully ..")
    })

});

app.put("/books/:id", (req,res)=>{
    const q = "UPDATE Books set `title`=?,`description`=?,`cover`=?,`price`=? where id=?";
    const values = [
        req.body.title,
        req.body.description,
        req.body.cover,
        req.body.price,
        req.params.id
    ]

    db.query(q, [values], (err, data)=>{
        if(err) return res.json(err);
        return res.json("Book has been updated successfully ..")
    })

});


app.listen(8080, ()=>{
    console.log("Server started on port 8080 ...");
})