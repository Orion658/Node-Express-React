import {BrowserRouter, Routes, Route} from 'react-router-dom';
import Books from './pages/Books';
import Add from './pages/Add';
import Update from './pages/Update';
import './styles.css';

function App() {
  return (
    <div className="App">
      {/* install a react-router-dom for path routing BrowserRouter is for routing  within application */}
      <BrowserRouter>
      <Routes>
        <Route path='/' element={<Books></Books>}/>
        <Route path='/add' element={<Add></Add>}/>
        <Route path='/update/:id' element={<Update></Update>}/>
      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
