import React, { useState } from 'react'
import axios from 'axios';
import { useLocation, useNavigate } from 'react-router-dom';
const baseURL = "http://localhost:8080";

const Update = () => {
  const [book, setBook] = useState({
    "title":"",
    "description":"",
    "price":null,
    "cover":""
  });

  // useLocation hook to extract id from URL 
  const location = useLocation();
  const bookID = location.pathname.split('/')[2];

  // To fetch prev data 
  // useEffect(() => {
  //   const fetchBookDetails = async () => {
  //     try {
  //       const response = await axios.get(`${baseURL}/books/${bookID}`);
  //       setBook(response.data);
  //       console.log(response.data); // Log the fetched data to check if it's coming correctly
  //     } catch (error) {
  //       console.log(error);
  //     }
  //   };

  //   fetchBookDetails();
  // }, [bookID]);

  // server side routing 
  const navigate = useNavigate();

  const handleChange = (e) => {
    setBook((prev) =>({...prev, [e.target.name]: e.target.value}));
  };

  const handleClick = async (e) => {
    e.preventDefault(); // by default it refresh the page ...
    try{
      await axios.put(baseURL+"/books/"+bookID, book)
      console.log(book);
      navigate("/")
    }catch(err){
      console.log(err);
    }
  }

  return (
    <div className="form">
      <h1>Update the Book</h1>
      <input type="text" placeholder='Book Name' name='title' onChange={handleChange}/>
      <textarea type="text" placeholder='Description' name='description' onChange={handleChange} rows="4"/>
      <input type="number" placeholder='Price' name='price' onChange={handleChange}/>
      <input type="text" placeholder='image (.png) file' name='cover' onChange={handleChange}/>
      <button onClick={handleClick} className='formButton'>Update</button>
    </div>
  )
}

export default Update
