import React from 'react';

const FoodListComponent = ({ foods }) => {
  return (
    <div>
      <h2>Food List</h2>
      <table>
        <thead>
          <tr>
            <th>Food Id</th>
            <th>Food Name</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          {foods.map((food) => (
            <tr key={food.foodId}>
              <td>{food.foodId}</td>
              <td>{food.foodName}</td>
              <td>{food.price}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default FoodListComponent;
