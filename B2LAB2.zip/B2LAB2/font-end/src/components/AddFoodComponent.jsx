import React, { useRef, useState } from 'react';

const AddFoodComponent = ({ addFood }) => {
  const [foodIdCounter, setFoodIdCounter] = useState(1);
  const errMsgRef = useRef(null);

  const [food, setFood] = useState({
    foodId: '',
    foodName: null,
    price: null
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFood({ ...food, [name]: value });
  };

  const handleAddFood = () => {
    errMsgRef.current.innerHTML = '';
    if (!food.foodName || !food.price ) {
      errMsgRef.current.innerHTML = 'Invalid input';
      return ;
    }

    // fine below
    const newFood = { ...food, foodId: foodIdCounter.toString() };
    addFood(newFood);

    // Increment the food ID counter for the next food
    setFoodIdCounter(foodIdCounter + 1);

    setFood({
      foodId: '',
      foodName: null,
      price: null,
    });
  };

  return (
    <div>
      <h2>Add food</h2>
      <form>
        {/* The food Id input is now disabled and auto-populated */}
        <label>food Id:</label>
        <input type="text" name="foodId" value={foodIdCounter} disabled />

        <label>food Name:</label>
        <input type="text" name="foodName" value={food.foodName} onChange={handleInputChange} required />

        <label>Price:</label>
        <input type="number" name="price" value={food.price} onChange={handleInputChange} required />

        <button type="button" onClick={handleAddFood}>
          Add food
        </button>
        <div ref={errMsgRef} id="errmsg"></div>
      </form>
    </div>
  );
};

export default AddFoodComponent;

