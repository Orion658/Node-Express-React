import React, { useState } from 'react'
import AddFoodComponent from './components/AddFoodComponent'
import FoodListComponent from './components/FoodListComponent'
import './styles.css'

const App = () => {
  const [foods, setFoods] = useState([]);

  const addFood = (newFood) => {
    setFoods([...foods, newFood]);
  };

  return (
    <div className="container">
      <h1>Food Web Application</h1>
      <AddFoodComponent addFood={addFood} />
      <FoodListComponent foods={foods} />
    </div>
  );
}

export default App
