import React, { useState } from 'react'
import AddEvent from './components/AddEvent'
import EventList from './components/EventList'
import './styles.css'

const App = () => {
  const [events, setEvents] = useState([]);

  const addEvent = (newEvent) => {
    setEvents([...events, newEvent]);
  };

  return (
    <div className="container">
      <h1>Event Management App</h1>
      <AddEvent addEvent={addEvent} />
      <EventList events={events} />
    </div>
  );
}

export default App
