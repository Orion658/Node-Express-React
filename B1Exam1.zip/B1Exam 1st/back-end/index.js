// server.js
const express = require('express');
const bodyParser = require('body-parser');
const app = express();

app.use(bodyParser.json());

const events = [];
let idCounter = 1;

// POST /new - Add new event
app.post('/new', (req, res) => {
  const { title, desc, date } = req.body;
  if (!title || !desc || !date) {
    return res.status(400).json({ error: 'Please provide valid data' });
  }
  const newEvent = {
    id: idCounter++,
    title,
    desc,
    date
  };

  events.push(newEvent);
  res.status(201).json({newBook, message: 'Event added successfully', event: newEvent });
});

// GET /list - List all events
app.get('/list', (req, res) => {
  res.json(events);
});

app.listen(8080, () => {
  console.log('Server is running on port 8080');
});
